frutas = ["manzana " , "banana", "cereza", "datil"] 
print "elemento 0. " , frutas [0]
frutas, append ("kiwi")
frutas. insert(2, "pera")
frutas.remove("kiwi")
print (lista final: , frutas) 