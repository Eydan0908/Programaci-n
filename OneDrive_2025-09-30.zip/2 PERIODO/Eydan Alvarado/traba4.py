cuidades=["lima", "san jose", "puriscal", " guanacaste"]"]
print(len(cuidades)
esta = "londres" in cuidades)