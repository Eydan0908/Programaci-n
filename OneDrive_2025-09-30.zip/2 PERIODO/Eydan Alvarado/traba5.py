mixto = [ 1,3,14 " hola mundo" true, none]
print(mixta)
for elemento in mixta
print(type(elemento))]